COL file_name FOR a80
SET lines 500 pages 900 feed ON
COL error FOR a30
COL tablespace_name FOR a20
SELECT hxfil file_num,SUBSTR(hxfnm,1,70) file_name,fhscn file_scn FROM x$kcvfh ORDER BY 1;
SELECT fuzzy, status, error, recover, checkpoint_change#, checkpoint_time, COUNT(*) 
from v$datafile_header GROUP BY fuzzy, status, error, recover, checkpoint_change#, checkpoint_time ;
select min(FHSCN) "LOW FILEHDR SCN", max(FHSCN) "MAX FILEHDR SCN", max(FHAFS) "Min PITR ABSSCN" from X$KCVFH ;
SELECT hxfil file#, SUBSTR(hxfnm, 1, 70) file_name, fhscn checkpoint_change#, fhafs Absolute_Fuzzy_SCN, MAX(fhafs) OVER () Min_PIT_SCN FROM x$kcvfh WHERE fhafs!=0 ORDER BY 1;
SELECT file#, SUBSTR(name, 1, 70) file_name, SUBSTR(tablespace_name, 1, 20) tablespace_name, undo_opt_current_change# FROM v$datafile_header WHERE fuzzy='YES' ORDER BY 1;
SELECT file#, SUBSTR(name, 1, 70) file_name, status, error, recover FROM v$datafile_header ORDER BY 1;

select dbid, name, created, open_mode, log_mode,controlfile_type,to_char(controlfile_change#, '999999999999999') as controlfile_change#,to_char(controlfile_time, 'DD-MON-RRRR HH24:MI:SS') controlfile_time from v$database;

select open_mode,current_scn,checkpoint_change#,archive_change#,controlfile_change#,controlfile_type from v$database;

select * from (select file#,name,substr(status,1,3) sta,error err,recover rec,fuzzy fuz,checkpoint_time checkpoint from v$datafile_header)
natural join (select hxfil file#, fhsta, fhscn, fhrba_seq, fhafs from x$kcvfhall);