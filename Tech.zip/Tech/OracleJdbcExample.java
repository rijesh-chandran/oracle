//
// export CLASSPATH=$ORACLE_HOME/jdbc/lib/ojdbc8.jar:.
// export PATH=$ORACLE_HOME/jdk/bin:$PATH
//
import java.lang.*;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import oracle.jdbc.OracleDriver;

public class OracleJdbcExample
{
    public static void main(String args[]) throws Exception 
	{
        //String url = "jdbc:oracle:thin:@<SCAN-NAME>:<PORT>/<SERVICE_NAME>";
        String url = "jdbc:oracle:thin:@scan01-644669.racscan.com:1521/ASCXPROD";

        Properties props = new Properties();
        props.setProperty("user", "agile");
        props.setProperty("password", "agile");

        DriverManager.registerDriver(new OracleDriver());

        Connection conn = DriverManager.getConnection(url,props);

        String sql ="select instance_name,host_name from v$instance";

        PreparedStatement preStatement = conn.prepareStatement(sql);

        ResultSet result = preStatement.executeQuery();

        System.out.println("");
        while(result.next()){
            System.out.println("Instance Name from Oracle : " + result.getString("instance_name"));
            System.out.println("Host Name from Oracle : " + result.getString("host_name"));
        }
			
        System.out.println("");
    }
}