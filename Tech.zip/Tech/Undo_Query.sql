with
tbsp_size as
(
select t.tablespace_name, sum(df.bytes)/1024/1024 tam_mb
from dba_tablespaces t
join dba_data_files df on t.tablespace_name = df.tablespace_name
where t.contents = 'UNDO'
group by t.tablespace_name
),
undo_ext as
(
select ue.tablespace_name, ue.status, sum(ue.blocks) * (select value from v$parameter where name = 'db_block_size')/1024/1024 tam_mb
from dba_undo_extents ue
group by ue.tablespace_name, ue.status
)
select ts.tablespace_name, ue.status, ue.tam_mb, round(ue.tam_mb/ts.tam_mb, 2) * 100 perc
from tbsp_size ts
join undo_ext ue on ts.tablespace_name = ue.tablespace_name
order by ts.tablespace_name, ue.status;