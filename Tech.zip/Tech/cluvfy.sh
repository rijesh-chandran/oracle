1. Do a ping test
2. Do 'ocrcheck -local' everyday twice 
3. Relocate the OLR to another disk location by updating olr.loc file.

a) cluvfy stage -post hwos -n dcn1pclx74a,dcn1pclx74b -verbose
b) cluvfy stage -post crsinst -n dcn1pclx74a,dcn1pclx74b -verbose

ping -M do -s 8972 192.168.1.2
