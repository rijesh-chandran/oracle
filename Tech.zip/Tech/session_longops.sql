SELECT opname, username, sql_fulltext, to_char(start_time,'DD-MON-YYYY HH24:MI:SS'),
(sofar/totalwork)*100 "%_complete", time_remaining, s. con_id
FROM v$session_longops s INNER JOIN v$sql sl USING (sql_id) 
WHERE time_remaining > 0;