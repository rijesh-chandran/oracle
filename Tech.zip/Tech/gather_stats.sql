-- exec DBMS_AUTO_TASK_IMMEDIATE.GATHER_OPTIMIZER_STATS;
select * from dba_autotask_client_job;
select * from dba_optstat_operations where operation like '%auto%' order by start_time desc fetch first 10 rows only;
select * from dba_optstat_operation_tasks where opid=679 and target not like '%"SYS".%';
select owner,table_name,partition_name,object_type,num_rows,blocks,last_analyzed,global_stats,user_stats,stattype_locked,stale_stats from dba_tab_statistics where owner='SYSADM' and table_name='CORE_DATA' order by partition_name nulls first;
select table_owner,table_name,partition_name,subpartition_count,high_value,partition_position,num_rows,blocks,sample_size,last_analyzed from dba_tab_partitions where table_owner='SYSADM' and table_name='CORE_DATA';
select * from dba_tab_modifications where table_owner='SYSADM';

alter session set nls_date_format='DD-MM-YY HH24:MI:SS';

select partition_name,sample_size,num_rows,  LAST_ANALYZED
from dba_tab_partitions
where table_owner='SYSADM'
and table_name='CORE_DATA'
order by partition_name;

select table_name,sample_size,num_rows,  LAST_ANALYZED
from dba_tables
where owner='SYSADM'
and table_name='CORE_DATA';

SET timing ON 
EXEC DBMS_STATS.GATHER_TABLE_STATS (ownname=> 'SYSADM', tabname=> 'CORE_DATA', partname=> 'SYS_P1109', estimate_percent=>10, degree=>1);
 
   ownname          VARCHAR2, 
   tabname          VARCHAR2, 
   partname         VARCHAR2 DEFAULT NULL,
   estimate_percent NUMBER   DEFAULT to_estimate_percent_type (get_param('ESTIMATE_PERCENT')),
												  
SELECT bytes/1024/1024 FROM dba_segments WHERE segment_name='CORE_DATA' and owner='SYSADM' and partition_name='SYS_P1109';

1. Lock the statistics for SYSADM.CORE_DATA
2. Create a job for gathering the stats for SYSADM.CORE_DATA with estimate_percent=>5, degree=>2 
3. Inside the job:
		unlock the stats 
		gather the stats 
		lock the stats 